/*veremos el setter y el getter*/
#include <iostream>
#include <stdlib.h>

using namespace std;

class Punto{
    private:
    int x,y;
    public:
    Punto();
    ~Punto();
    void setpuntox(int, int);
    int getpuntox();
    int getpuntoy();
};
Punto::Punto()
{

}
Punto::~Punto()
{

}
void Punto::setpuntox(int _x , int _y)
{
    x=_x;
    y=_y;
}
int Punto::getpuntox()
{
    return x;
}
int Punto::getpuntoy()
{
    return y;
}
int main()
{
    Punto punto1;
    punto1.setpuntox(15,20);
    cout<<punto1.getpuntox()<<endl;
     cout<<punto1.getpuntoy()<<endl;
    return 0;
}