#include <iostream>
#include <fstream>
#include <string>
#include <locale>
#include <wchar.h>
#include <cstdlib>

using namespace std;
struct ejer21
{
    string Narchivo, texto, altex, op;
};
void pedir(ejer21 &ped);
void mostrar(ejer21 mos);
int main()
{
    setlocale(LC_ALL, "es_Es");
    ejer21 datos;
    pedir(datos);
    cout << "Programa que visualiza los fatos del archivo registro" << endl;
    cout << "-----------------------------------------------------" << endl
         << endl
         << endl
         << endl
         << endl;
    mostrar(datos);
    return 0;
}
void pedir(ejer21 &ped)
{
    cout << "Por favor, dime el nombre del archivo: ";
    getline(cin, ped.Narchivo);
}
void mostrar(ejer21 mos)
{
    do
    {
        ifstream archivo;
        archivo.open(mos.Narchivo.c_str(), ios::in);
        if (archivo.fail())
        {
            "Error al buscar/generar el archivo";
        }
        cout << "Nombre \t Apellido \t Edad \t Ciudad \t Género \t Profesión \t Afición" << endl;
        cout << "--------------------------------------------------------------------------------------------" << endl;

        while (!archivo.eof())
        {
            getline(archivo, mos.altex);
            for (int i = 0; i < mos.altex.length(); i++)
            {
                if (mos.altex[i] == ' ')
                {
                    mos.altex[i] = '\t';
                }
            }
            cout << mos.altex << endl;
        }
        cout << "--------------------------------------------------------------------------------------------" << endl
             << endl
             << endl
             << endl;
        cout << "Deseas revisar otro archivo:s/n";
        getline(cin, mos.op);
        while (mos.op != "s" && mos.op != "S" && mos.op != "n" && mos.op != "N")
        {
            cout << "Parametro incorrecto "<<endl;
            system("pause");
            cout << "Deseas revisar otro archivo:s/n: ";
            getline(cin, mos.op);
        }
        if (mos.op == "n" && mos.op == "N")
        {
            exit(1);
        }

    } while (mos.op == "s" && mos.op == "S");
}