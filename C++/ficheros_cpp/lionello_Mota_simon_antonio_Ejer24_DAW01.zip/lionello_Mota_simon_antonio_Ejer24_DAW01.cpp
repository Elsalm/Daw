
#include <iostream>
#include <fstream>
#include <locale.h>
#include <wchar.h>
#include <cstdlib>

using namespace std;

struct ejer24
{
    string codigo, nombres, apellidos, edad, ciudad, genero, consulta;
    bool opcion;
    char sn;
    int cont = 1;
};

void agregar(ejer24 ag);
void nomap(ejer24 &no); /*nombre y apellido*/
void mostrar();

int main()
{
    setlocale(LC_ALL, "");
    ejer24 datos;
    cout << "Programa para agregar los datos de un asso en asesoria.txt" << endl;
    cout << "----------------------------------------------------------" << endl
         << endl
         << endl;
    do
    {
        
        agregar(datos);
        mostrar();
        datos.opcion = true;
        cout << "quieres seguir editando?(S/N):";
        cin >> datos.sn;
        fflush(stdin);
        while (datos.sn != 's' and datos.sn != 'S' and datos.sn != 'n' and datos.sn != 'N')
        {
            cout << "parametro introducido no valido" << endl;
            cout << "-------------------------------" << endl
                 << endl;
            cout << "quieres seguir editando?(S/N):";
            cin >> datos.sn;
            fflush(stdin);
        }
        if (datos.sn == 'N' or datos.sn == 'n')
        {
            datos.opcion = false;
        }
    } while (datos.opcion);
    cout<<"has salido del programa!";
    return 0;
}

void agregar(ejer24 ag)
{

    ofstream archivo;

    archivo.open("asesoria.txt", ios::app);

    if (archivo.fail())
    {
        cout << "No se ha podido encontrar/crear el fichero asesoria.txt";
        exit(1);
    }

    do
    {
           if (ag.cont>1)
        {
            system("cls");
        }
        cout << "\t \t agregar datos " << ag.cont << endl;
        cout << "\t \t -------------" << endl
             << endl;
        cout << "codigo: ";
        getline(cin, ag.codigo);
        cout << "nombres: ";
        getline(cin, ag.nombres);
        cout << "apellidos: ";
        getline(cin, ag.apellidos);
        cout << "edad: ";
        getline(cin, ag.edad);
        cout << "ciudad: ";
        getline(cin, ag.ciudad);
        cout << "genero: ";
        getline(cin, ag.genero);
        cout << "consulta: ";
        getline(cin, ag.consulta);
        nomap(ag);

        archivo << ag.codigo << " " << ag.nombres << " " << ag.apellidos << " " << ag.edad << " " << ag.ciudad << " " << ag.genero << " " << ag.consulta << endl;

        cout << "te gustaria añadir mas datos?(S/N):";
        cin >> ag.sn;
        fflush(stdin);
        while (ag.sn != 's' and ag.sn != 'S' and ag.sn != 'n' and ag.sn != 'N')
        {
            cout << "parametro introducido no valido" << endl;
            cout << "-------------------------------" << endl
                 << endl;
            cout << "te gustaria añadis mas datos?(S/N):";
            cin >> ag.sn;
            fflush(stdin);
        }
        if (ag.sn == 'N' or ag.sn == 'n')
        {
            ag.opcion = false;
        }
        ag.cont++;
        /*idea, que siga agregando asesores hasta que tu le digas que no quieres agregar mas*/
        /*idea, que cuente cuantos asesores ha agregado*/

        /*Generar un programa que pueda agregar, tantos asesores como se desee, los
        datos de un asesor en el archivo asesoria.txt, luego se debe mostrar los datos de
        todos los asesores. Los campos del archivo asesoría son: código, nombres,
        apellidos, edad, ciudad, género y consulta. */
    } while (ag.opcion);
}

void mostrar()
{
    string texto;
    ifstream archivo;
    archivo.open("asesoria.txt", ios::in);
    if (archivo.fail())
    {
        cout << "no se ha podido encontrar el archivo" << endl;
        exit(1);
    }
    cout << "Codigo  nombres        apellidos        edad    cidudad    genero    consulta" << endl;
    cout << "---------------------------------------------------------------------------------------------------------------------------" << endl;
    while (!archivo.eof())
    {
        getline(archivo, texto);
        for (size_t i = 0; i < texto.length(); i++)
        {
            if (texto[i]==' ')
            {
                texto.replace(i, 1, "\t");
            }
            
        }
        
        cout << texto << endl;
    }
    cout << "---------------------------------------------------------------------------------------------------------------------------" << endl;
}

void nomap(ejer24 &no)
{
    for (size_t i = 0; i < no.nombres.size(); i++)
    {
        if (no.nombres[i] == ' ')
        {
            no.nombres.replace(i, 1, ".");
        }
        
    }

    for (size_t i = 0; i < no.apellidos.size(); i++)
    {
        if (no.apellidos[i] == ' ')
        {
            no.apellidos.replace(i, 1, ".");
        }
    }
    for (size_t i = 0; i < no.consulta.size(); i++)
    {
        if (no.consulta[i] == ' ')
        {
            no.consulta.replace(i, 1, ".");
        }
    }
};
