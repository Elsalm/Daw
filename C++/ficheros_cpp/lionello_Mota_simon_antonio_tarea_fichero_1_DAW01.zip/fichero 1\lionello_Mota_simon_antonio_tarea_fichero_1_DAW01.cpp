#include <iostream>
#include <locale.h>
#include <wchar.h>
#include<fstream>

using namespace std;
struct datos
{
    string Nfichero, frase;
    int cfrases;
};

void pedir(datos &ped);
void escribir(datos es);
int main()
{// Realice un programa que pida al usuario el nombre de un fichero de texto y, a continuación permita almacenar al usuario tantas frases como el usuario desee.
    setlocale(LC_ALL,"Spanish");
    datos dat;
    pedir(dat);
    escribir(dat);

}
void pedir(datos &ped)//esta funcion pide los datos
{
    cout<<"Por favor, introduce el nombre del fichero(.txt):";
    cin>> ped.Nfichero;
    cout<<endl<<"Cuantas frases quieres escribir?:";
    cin>>ped.cfrases;
    
}
void escribir(datos es)
{/*esta funcio utiliza el for para recibir todas las frases que hemos almacenado*/
    ofstream archivo;
    archivo.open(es.Nfichero, ios::out);
    if(archivo.fail()){cout<<"No se ha podido crear el archivo";exit(1);}
    for (int i = 0; i < es.cfrases; i++)
    {
        cout<<"Por favor, initroduce la " <<i+1<< "º" <<" frase"<<endl;
        cout<<"Frase: ";
        cin>>es.frase;
        archivo<<es.frase<<" ";
    }
    
}