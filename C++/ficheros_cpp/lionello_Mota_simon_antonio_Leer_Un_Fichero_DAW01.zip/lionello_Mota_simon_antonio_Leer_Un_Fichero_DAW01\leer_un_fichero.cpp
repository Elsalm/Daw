#include <iostream>
#include <locale>
#include<wchar.h>
#include<fstream>
 using namespace std;
 struct leer_un_fichero
 {
    string Nfichero,texto;
 };
 
 int main()
 {
    leer_un_fichero datos;
    cout << "Dame el nombre del fichero que quieres abrir:";
    getline(cin >> std::ws, datos.Nfichero);
    ifstream archivo;
    archivo.open(datos.Nfichero, ios::in);
    if (archivo.fail())
    {
        cout<<"No se pudo encontrar el archivo";
        exit(1);
    }
    while (!archivo.eof())
    {
        getline(archivo,datos.texto);
        cout<<datos.texto<<endl;
    }
    
return 0;
 }