#include <iostream>
#include <fstream>
#include <string>
#include <locale>
#include <wchar.h>
#include <cstdlib>

using namespace std;
const int TOPE = 1;
/*Generar un programa que capture por pantalla los datos de 10 registros de
 *crédito con los campos nit (cuatro últimos dígitos), nombres, apellidos, edad,
 *género, préstamo y plazo, genere el archivo de salida de nombre informe.txt.*/
struct ejer22
{
    string nit, nombres,apellidos ,edad, genero, prestamo, plazo, opcion;
};
void captura(int nreg,ejer22 cap);
void muestra();
int main()
{   setlocale(LC_ALL,"es_ES");
    ejer22 datos;
    do
    {  
        // captura(TOPE, datos);
        muestra();
        cout<<"Desea procesar Nuevamente?: S o N ";
        getline(cin,datos.opcion);
        while (datos.opcion!="s"&&datos.opcion!="S"&&datos.opcion!="n"&&datos.opcion!="N")
        {
            cout<<"parametro incorrecto(S/N).";
            cout<<"Desea procesar Nuevamente?: S o N ";
            getline(cin,datos.opcion);
        }
        if (datos.opcion== "n" || datos.opcion== "N")
        {
            cout<<"has salido del programa!"<<endl;
            system("pause");
            exit(1);
        }
        
        
    } while (datos.opcion== "s" || datos.opcion=="S");
    
   
}
void captura(int nreg,ejer22 cap)
{ cout<<"\t Programa que lee 10 registros y genera el archivo de salida informe.txt"<<endl;
    cout<<"\t ----------------------------------------------------------------------"<<endl;
    ofstream archivo;
    archivo.open("informe.txt",ios::out);
    if (archivo.fail())
    {   
        system("cls");
        cout<<"Error al buscar/generar el archivo. "<<endl;
        system("pause");
        exit(1);
    }
    
    for (int i = 0; i < nreg; i++)
    {   /*nit (cuatro últimos dígitos), nombres, apellidos, edad,
        *género, préstamo y plazo*/
        cout<<"Introducir datos "<<i+1<<"º"<<"registro"<<endl;
        cout<<"----------------------------------------"<<endl;
        cout<<"Nit(solo los 4 ultimos digitos):";
        getline(cin,cap.nit);
        cout<<"Nombre:";
        getline(cin,cap.nombres);
        cout<<"Apellido:";
        getline(cin,cap.apellidos);
        cout<<"Edad:";
        getline(cin,cap.edad);
        cout<<"genero:";
        getline(cin,cap.genero);
        cout<<"Prestamo:";
        getline(cin,cap.prestamo);
        cout<<"Plazo:";
        getline(cin,cap.plazo);
        archivo<<cap.nit+" "+cap.nombres+" "+cap.apellidos+" "+cap.edad+" "+cap.genero+" "+cap.prestamo+" "+cap.plazo<<endl;
    }  
}
void muestra()
{ string texto;
int tamaño=0;
system("cls");
cout<<"\t Programa que lee 10 registros y genera el archivo de salida informe.txt"<<endl;
    cout<<"\t ----------------------------------------------------------------------"<<endl<<endl<<endl;
    cout<<"";
    ifstream archivo;
    archivo.open("informe.txt", ios::in);
    if (archivo.fail())
    {
        cout<<"No se ha podido encontrar el archivo"<<endl;
        exit(1);
    }
    cout<<"\t\t Datos de los registros de credito"<<endl<<endl<<endl;
    cout<<"Nit.\tNombres \tApellidos\tEdad\tGenero\tPrestamo\tPlazo meses"<<endl;
    cout<<"----\t--------\t---------\t-----\t-------\t--------\t------------"<<endl;
    while (!archivo.eof())
    {   getline(archivo, texto,'\t');
        tamaño=texto.length();
        for (int i = 0; i <tamaño; i++)
        {
            if (texto[i]==' ')
            {   
                texto[i]='\t';
              
            } 
        }
        cout<<texto<<endl;  
    }
    cout<<"---- \t-------- \t---------\t-----\t-------\t--------\t------------"<<endl;
    

}