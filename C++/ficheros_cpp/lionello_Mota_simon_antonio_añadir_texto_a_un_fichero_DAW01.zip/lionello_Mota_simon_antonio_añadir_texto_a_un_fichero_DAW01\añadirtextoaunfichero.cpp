#include <iostream>
#include <stdlib.h>
#include <locale>
#include <wchar.h>
#include <fstream>
using namespace std;
struct añadirtextoaunfichero
{
    string Nfichero ,texto;
    char yn;
    bool res;
};
void editar(añadirtextoaunfichero ed);
int main()
{   setlocale(LC_ALL,"Spanish");
    /* Realice un programa que pida al usuario el nombre de un fichero de texto y, 
    a continuación permita al usuario poder incluir en el fichero lo que quiera.*/
    añadirtextoaunfichero datos;
    cout<<"Por favor, introduzca el nombre del fichero:";
    getline(cin, datos.Nfichero);
    editar(datos);
    
    
}
void editar(añadirtextoaunfichero ed)
{
    ofstream archivo;
    archivo.open(ed.Nfichero.c_str(), ios::app);
    if (archivo.fail())
    {
        cout<<"No se ha podido encontrar el archivo"<<endl;
        exit(1);
    }
    cout <<"Por favor introduce lo que quieras añadir:";
    getline(cin, ed.texto);
    archivo<<ed.texto<<endl;
    
}