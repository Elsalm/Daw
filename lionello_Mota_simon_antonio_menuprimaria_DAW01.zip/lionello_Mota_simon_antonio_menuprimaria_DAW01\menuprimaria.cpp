#include <iostream>
#include <fstream>
#include <locale.h>
#include <wchar.h>
using namespace std;
int main()
{
    ofstream archivo;
    archivo.open("menuprimaria.txt", ios::out);
    if (archivo.fail())
    {
        cout << "No se pudo abrir el archivo";
    }
    archivo << "|--------------------------|" << endl;
    archivo << "| Vamos a hacer calculos   |" << endl;
    archivo << "|--------------------------|" << endl;
    archivo << "|1. Calcular el Perimetro  |" << endl;
    archivo << "|2. Calcular el Area       |" << endl;
    archivo << "|3. Calcular el Volumen    |" << endl;
    archivo << "|4. Salir                  |" << endl;
    archivo << "|--------------------------|" << endl;

    return 0;
}