#include <iostream>
#include <cstdlib>
#include <fstream>
#include <locale.h>
#include <wchar.h>
using namespace std;
const int TOPE = 1;
struct dat
{
    string op, codi, codigo, nombre, apellidos, edad, ciudad, genero, consulta;
    bool control = false;
};
void escribir(dat es);
int main()
{
    dat datos;
    do
    {
    cout << "por favor introducir el codigo: ";
    getline(cin, datos.codi);

    escribir(datos);
    cout<<"Desea realizar otra consulta(s/n)?:";
    getline(cin,datos.op);
    while (datos.op != "s" && datos.op != "S" && datos.op != "N" && datos.op != "n")
    {
        system("cls");
        cout <<"Parametro no valido."<<endl;
        cout<<"Desea realizar otra consulta(s/n)?:";
         getline(cin,datos.op);
    }
    if (datos.op=="n" || datos.op=="N")
    {
       cout<<"has salido del programa.";
       break;
    }
    
    
       
    } while (datos.op =="s" ||  datos.op == "S");
    
    
}
void escribir(dat es)
{
    ifstream archivo;
    archivo.open("asesoria.txt", ios::in);
    if (archivo.fail())
    {
        cout << "No se ha encontrado el archivo" << endl;
        exit(1);
    }

    while (!archivo.eof())
    {
        archivo >> es.codigo;
        if (es.codi == es.codigo)
        {
            es.control = true;
            archivo >> es.nombre;
            archivo >> es.apellidos;
            archivo >> es.edad;
            archivo >> es.ciudad;
            archivo >> es.genero;
            archivo >> es.consulta;
        }
    }
    if (es.control)
    {
        cout << "\t \t Datos de asesor" << endl;
        cout << "\t \t ---------------" << endl;
        cout << "    Nombre        apellido       ciudad   edad    genero        consulta" << endl;
        cout << es.nombre << "\t" << es.apellidos << "    " << es.edad << "    " << es.ciudad << "    " << es.genero << "\t" << es.consulta << endl;
        cout << endl;
    }
    else
    {
        cout<<"no se ha encontrado el codigo"<<endl;
    }
    archivo.close();
}
